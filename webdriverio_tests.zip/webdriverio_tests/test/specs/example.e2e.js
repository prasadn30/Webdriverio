
describe('Submit form with only required fields',function(){
    it('enter age', function(){
        browser.url('/');
        const search = await $('#current-age');
        await search.setValue('40');
    })

    it('retirement age', function(){
        
        const search =await $('#retirement-age');
        await search.setValue('68');
    })

    it('current annual income', function(){
       
        const search = await $('#current-income');
        await search.setValue('100000');
    })

    it('current-total-savings', function(){
        
        const search = await $('#current-total-savings');
        await search.setValue('500000');
    })

    it('current-annual-savings', function(){
        
        const search = await $('#current-annual-savings');
        await search.setValue('60');
    })

    it('savings-increase-rate', function(){
        
        const search =await $('#savings-increase-rate');
        await search.setValue('60');
    })

    it('submit button', function(){
       
        const submitBtn =await $("button[data-tag-id='submit']");
        await radioBtn.click();
    })
    
});




describe('Submit form with all fields',function(){
    it('enter age', function(){
        browser.url('/');
        const search = await $('#current-age');
        await search.setValue('40');
    })

    it('retirement age', function(){
       
        const search =await $('#retirement-age');
        await search.setValue('68');
    })

    it('current annual income', function(){
       
        const search = await $('#current-income');
        await search.setValue('100000');
    })

    it('spouse income', function(){
       
        const search =await $('#spouse-income');
        await search.setValue('75000');
    })

    it('current-total-savings', function(){

        const search = await $('#current-total-savings');
        await search.setValue('500000');
    })

    it('current-annual-savings', function(){
      
        const search = await $('#current-annual-savings');
        await search.setValue('60');
    })

    it('savings-increase-rate', function(){
       
        const search =await $('#savings-increase-rate');
        await search.setValue('60');
    })

    it('no-social-benefits', function(){
       
        const nosocialbenefitsBtn =await $('#no-social-benefits');
        await nosocialbenefitsBtn.click();
    })

    it('submit button', function(){
      
        const submitBtn =await $("button[data-tag-id='submit']");
        await radioBtn.click();
    })
    
    
});

describe('Submit form with all fields',function(){
    it('enter age', function(){
        browser.url('/');
        const search = await $('#current-age');
        await search.setValue('40');
    })

    it('retirement age', function(){
       
        const search =await $('#retirement-age');
        await search.setValue('68');
    })

    it('current annual income', function(){
       
        const search = await $('#current-income');
        await search.setValue('100000');
    })

    it('spouse income', function(){
    
        const search =await $('#spouse-income');
        await search.setValue('75000');
    })

    it('current-total-savings', function(){
      
        const search = await $('#current-total-savings');
        await search.setValue('500000');
    })

    it('current-annual-savings', function(){
      
        const search = await $('#current-annual-savings');
        await search.setValue('6000');
    })

    it('savings-increase-rate', function(){
       
        const search =await $('#savings-increase-rate');
        await search.setValue('10');
    })

    it('no-social-benefits', function(){
       
        const nosocialbenefitsBtn =await $('#no-social-benefits');
        await nosocialbenefitsBtn.click();
    })

    it('select Married check box', function(){
       
        const MarriedBtn =await $("label[for='Married']");
        await MarriedBtn.click();
    })

    
    it('savings-increase-rate', function(){
      
        const socialbenefitsBtn =await $('#no-social-benefits');
        await socialbenefitsBtn.click();
    })

    it('social-security-override-amount', function(){
      
        const search =await $('#social-security-override');
        await search.setValue('10000');
    })

    it('submit button', function(){
      
        const submitBtn =await $("button[data-tag-id='submit']");
        await radioBtn.click();
    })
    
    
});

describe('updating default values with user defined values',function(){
    it('enter age', function(){
        browser.url('/');
        const search = await $('#current-age');
        await search.setValue('40');
    })

    it('retirement age', function(){
       
        const search =await $('#retirement-age');
        await search.setValue('68');
    })

    it('current annual income', function(){
      
        const search = await $('#current-income');
        await search.setValue('100000');
    })

    it('spouse income', function(){
        
        const search =await $('#spouse-income');
        await search.setValue('75000');
    })

    it('current-total-savings', function(){
       
        const search = await $('#current-total-savings');
        await search.setValue('500000');
    })

    it('current-annual-savings', function(){
      
        const search = await $('#current-annual-savings');
        await search.setValue('6000');
    })

    it('savings-increase-rate', function(){
      
        const search =await $('#savings-increase-rate');
        await search.setValue('10');
    })

    it('no-social-benefits', function(){
      
        const nosocialbenefitsBtn =await $('#no-social-benefits');
        await nosocialbenefitsBtn.click();
    })

    it('select Married check box', function(){
        
        const MarriedBtn =await $("label[for='Married']");
        await MarriedBtn.click();
    })

    
    it('savings-increase-rate', function(){
        
        const socialbenefitsBtn =await $('#no-social-benefits');
        await socialbenefitsBtn.click();
    })

    it('social-security-override-amount', function(){
       
        const search =await $('#social-security-override');
        await search.setValue('10000');
    })

    it('submit button', function(){
      
        const submitBtn =await $("button[data-tag-id='submit']");
        await radioBtn.click();
    })
    
    
});